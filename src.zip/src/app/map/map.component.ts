import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import {Location} from '../locations/location';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {

  @Input() locations: Location;
  //@Output() getLocation = new EventEmitter<Object>();
  
  msg:string ="";

  //the component as the initial center of the map:
  lat: number = 	65.28833501617348;
  long: number = 86.4527256076122;

  private url : string = "http://localhost:8080/api/locations/";

  constructor(private http: HttpClient) { }

  ngOnInit(){
    
  }
 
}
