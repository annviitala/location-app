import { Injectable } from '@angular/core';
import { Location} from './location';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()

export class LocationService {
    location : Location;
    
    private url : string = "http://localhost:8080/api/locations/";
    private http: HttpClient
    constructor(http: HttpClient) { 
      this.http = http
    }
  
    //data fetch from the Service pass to location.component
    /*fetch() : Location[] {
        // return an array of location objects
        return  [{id: 1, latitude: 50.00, longitude: 60.00}, 
            {id: 2, latitude: 51.00, longitude: 61.00}] 
        
    }*/
    // Uses http.get() to load data from a single API endpoint
    fetch() {
        return this.http.get<Location>(this.url);
    }

    // send a POST request to the API to create a new data object
    sendToServer(body: any) {
        return this.http.post(this.url, body, {observe:'response'});
    }

    // send a DELETE request to the API to delete a data object
     deleteLocation(locationId : string) {        
        return this.http.delete(this.url + locationId, { observe: 'response', responseType: 'text' });
    }

}
