import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { LocationService } from './location.service';
import { Location} from './location';
import { AddComponent } from '../add/add.component';
import { MapComponent } from '../map/map.component';

@Component({
  selector: 'app-locations',
  template: `<app-map [locations]="locations" ></app-map>
            <table border="1">
              <thead>
                  <tr>
                    <th>#</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th>Action</th>
                  </tr>
              </thead>
              <tbody>
                  <!-- iterate for each location -->
                  <tr *ngFor="let loc of locations">
                     <td>{{loc.id}}</td> 
                     <td>{{loc.latitude}}</td> 
                     <td>{{loc.longitude}}</td> 
                     <td><button (click)="deleteLocation(loc.id)">Delete</button></td>
                  </tr>
                  <tr>
                    <app-add></app-add>
                  </tr>
              </tbody>
            </table>
            `
            
})
export class LocationsComponent implements OnInit {  
  locations : Location;
  //data access from the component
  /*locations: Object[] = [{id: 1, latitude: 50.00, longitude: 60.00}, 
    {id: 2, latitude: 51.00, longitude: 61.00}] 
  */
    //locations: Location[] = [];
    
    /*constructor(locationService :  LocationService) {
      //data from the service being fetched
    this.locations = locationService.fetch();
   }*/
   constructor(private locationService : LocationService){

   }

   ngOnInit(): void {
    this.getLocation();
  }

  
  getLocation() : any {
    this.locationService.fetch().subscribe(
      // the first argument is a function which runs on success
      result => { this.locations = result;       
       //console.log(result);
      },
      // the second argument is a function which runs on error
      err => console.error(err),
      // the third argument is a function which runs on completion
      () => console.log('done loading location')
    );
  }

  //delete the element
  deleteLocation(locationId : string){
    this.locationService.deleteLocation(locationId).subscribe(result => {      
      //refresh the table after deleting
      this.getLocation();    
      console.log("deleted");      
    })
    
  }
}
