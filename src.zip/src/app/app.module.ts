import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FirstCharUpperCasePipe } from './firstcharuppercase.pipe';
import { LocationService } from './locations/location.service';
import {Location } from './locations/location';
import { HttpClientModule} from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LocationsComponent } from './locations/locations.component';
import { AddComponent } from './add/add.component';
import { AgmCoreModule } from '@agm/core';
import { MapComponent } from './map/map.component';


@NgModule({
  declarations: [
    AppComponent,
    FirstCharUpperCasePipe,
    LocationsComponent,
    AddComponent,
    MapComponent

  ],
  imports: [
    BrowserModule, HttpClientModule, FormsModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBmTb0yJCRXt9TV4GhLFo9yePUY25cPo2Q'
    }) 
  ],
  providers: [LocationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
