import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  //templateUrl: './app.component.html',
  template: `<h1>{{title | firstcharuppercase}} </h1>
              <p>Today is {{todayDate | date:'yyyy.MM.dd'}}</p>
              <app-locations ></app-locations>`
})
export class AppComponent {
  title = 'Locations - App';
  todayDate : Date = new Date();
  

}
