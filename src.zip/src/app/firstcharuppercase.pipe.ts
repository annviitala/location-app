import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'firstcharuppercase'})

export class FirstCharUpperCasePipe implements PipeTransform {
  transform(giventext: string): string {
    return "Location - App"
  }
}
