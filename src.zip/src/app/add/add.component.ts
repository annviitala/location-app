import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpResponse} from '@angular/common/http';
import { LocationService } from '../locations/location.service';
import {Location} from '../locations/location';
import {LocationsComponent} from '../locations/locations.component';



@Component({
  selector: 'app-add',
  template: `<td></td>
            <td><input type="number" placeholder="latitude" name="latitude" [(ngModel)]="latitude"/></td>
            <td><input type="number" placeholder="longitude" name="longitude" [(ngModel)]="longitude"/></td>
            <td><button (click)="sendToServer(location)">Add New</button></td>
            `
})
export class AddComponent {
  latitude: number;
  longitude: number;
  location : Location;
  msg:string="";
  //locationcomp:LocationsComponent;

  constructor(private locationService : LocationService, private locationsComp: LocationsComponent) { }

    sendToServer(body : any){
      body = {"latitude": this.latitude, "longitude": this.longitude};
      
      this.locationService.sendToServer(body).subscribe(this.success.bind(this), this.error.bind(this))
    
    }

    error(err: HttpErrorResponse){
      this.msg = "Some problem with saving data."
    }
    success(response : HttpResponse<Location>){
         
      let locationObject: Location = response.body;
      this.msg =`Saved with an id of ${locationObject}`

      // refresh table to show added element 
      this.getLoc();
    }
    // declare getLocation method from LocationsComponent
    getLoc() : any{
      //declare the method that displays the table  
      return this.locationsComp.getLocation();
    }

}
